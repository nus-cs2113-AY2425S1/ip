package aether.command;

/**
 * Enum to represent different types of tasks.
 */
public enum TaskType {
    TODO,
    DEADLINE,
    EVENT;
}
